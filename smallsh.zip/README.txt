README

In order to compile and run this program, please do the following:

1. In your shell, navigate to the directory of this readme file.
2. To compile the code, run the following command, without quotations: "gcc --std=gnu99 Builtins.c ChildMan.c InputHandler.c IO.c SigMan.c smallsh.c Util.c -o smallsh"
3. No arguments are needed to run this program, thus, assuming you named the program smallsh as stated above, use the command, without quotations, "smallsh"