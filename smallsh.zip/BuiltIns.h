#ifndef BUILTINS_H_INCLUDED
#define BUILTINS_H_INCLUDED

void shellExit(void);
void shellCD(char* filePath);
void shellStatus(int** fgExitStatus);

#endif